@echo off
:: 沙雕动画小助手插件安装器 - 启动脚本
:: 此脚本用于启动 PowerShell 安装程序

cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0tools\install_plugin.ps1"
