﻿# ==========================================
#      沙雕动画小助手 - 一键安装脚本
# ==========================================

# 切换到脚本所在目录的父目录（Release_Package 根目录）
Set-Location -Path (Split-Path -Parent $PSScriptRoot)

# 配置变量
$ZXP_FILE = "aitalk.cloud沙雕动画小助手插件.zxp"
$EXTENSION_ID = "com.FunnyAnimationAssistant.exporter.panel"
$TARGET_DIR = "$env:APPDATA\Adobe\CEP\extensions\$EXTENSION_ID"

$Host.UI.RawUI.WindowTitle = "沙雕动画小助手插件安装器"

Write-Host ""
Write-Host " [1/3] 正在检查环境..." -ForegroundColor White

# 1. 检查安装包文件
if (-not (Test-Path $ZXP_FILE)) {
    Write-Host ""
    Write-Host " [错误] 未找到安装包: $ZXP_FILE" -ForegroundColor Red
    Write-Host " 请确认您已解压所有文件，并保持目录结构完整。" -ForegroundColor White
    Write-Host ""
    Read-Host " Press Enter to exit"
    exit 1
}

Write-Host " [2/3] 正在配置系统注册表 (开启调试模式)..." -ForegroundColor White

# 2. 自动修改注册表 (针对自签名证书必须开启 PlayerDebugMode)
foreach ($version in 10..16) {
    $regPath = "HKCU:\Software\Adobe\CSXS.$version"
    if (-not (Test-Path $regPath)) {
        New-Item -Path $regPath -Force | Out-Null
    }
    Set-ItemProperty -Path $regPath -Name "PlayerDebugMode" -Value "1" -Type String -Force
}
Write-Host "    - 调试模式已开启 (无需管理员权限)" -ForegroundColor Gray

Write-Host " [3/3] 正在安装插件 (开发者模式)..." -ForegroundColor White

# 3. 清理旧版本
if (Test-Path $TARGET_DIR) {
    Write-Host "    - 清理旧版本..." -ForegroundColor Gray
    Remove-Item -Path $TARGET_DIR -Recurse -Force -ErrorAction SilentlyContinue
}

# 4. 解压插件文件
Write-Host "    - 正在解压插件文件..." -ForegroundColor Gray
try {
    # 创建临时 Zip 文件名
    $TEMP_ZIP = "temp_installer_$(Get-Random).zip"
    Copy-Item -Path $ZXP_FILE -Destination $TEMP_ZIP -Force

    Expand-Archive -Path $TEMP_ZIP -DestinationPath $TARGET_DIR -Force
    
    # 清理临时文件
    Remove-Item -Path $TEMP_ZIP -Force -ErrorAction SilentlyContinue
} catch {
    Write-Host "    - 解压失败: $_" -ForegroundColor Red
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

# 5. 验证安装
if (Test-Path "$TARGET_DIR\CSXS\manifest.xml") {
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Green
    Write-Host "       恭喜！安装成功！" -ForegroundColor Green
    Write-Host "==========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "插件已部署到:" -ForegroundColor White
    Write-Host $TARGET_DIR -ForegroundColor Cyan
    Write-Host ""
    Write-Host "请重启 Adobe Animate 软件。" -ForegroundColor White
    Write-Host "在菜单栏 窗口 -> 扩展 中即可找到插件。" -ForegroundColor White
    Write-Host ""
    Read-Host " Press Enter to exit"
    exit 0
}

# 安装失败
Write-Host ""
Write-Host "==========================================" -ForegroundColor Red
Write-Host "       安装失败" -ForegroundColor Red
Write-Host "==========================================" -ForegroundColor Red
Write-Host ""
Write-Host "请尝试手动安装:" -ForegroundColor Yellow
Write-Host "1. 将 .zxp 文件后缀改为 .zip" -ForegroundColor White
Write-Host "2. 解压并将文件夹命名为 $EXTENSION_ID" -ForegroundColor White
Write-Host "3. 复制到: $env:APPDATA\Adobe\CEP\extensions\" -ForegroundColor White
Write-Host ""
Read-Host "Press Enter to exit"
exit 1
